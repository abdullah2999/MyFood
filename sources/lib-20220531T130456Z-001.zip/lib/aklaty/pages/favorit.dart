import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class FavScreen extends StatelessWidget{
  const FavScreen({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Color(0xffE6915D),
      title: Text('المفضلة'),
        leading: IconButton(
          onPressed: (){},
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
        ),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(40.0),
            child: Column(
              crossAxisAlignment:CrossAxisAlignment.center,
              children: [
                Container(
                  child: Image.asset('images/cheesscake.jpg'),
                  margin: EdgeInsets.only(top: 10.0),
                ),
                     Container(
                       margin: EdgeInsets.only(bottom: 20),
                       decoration: BoxDecoration(color: Color(0xffE6915D),
                         borderRadius: BorderRadius.only(
                           bottomRight: Radius.circular(20),
                           bottomLeft: Radius.circular(20),
                         ),
                       ),
                       height: 80,
                       child: Padding(
                         padding: const EdgeInsets.all(5.0),
                         child: Column(
                           children: [
                             Text('تشيز كيك',
                           style: TextStyle(
                             fontSize: 20.0,
                             letterSpacing: 2.0,
                             color: Colors.white,
                           ),
                         ),
                             Text('35 دقيقة',
                               style: TextStyle(
                                 fontSize: 15.0,
                                 letterSpacing: 2.0,
                                 color: Colors.white,
                               ),
                             ),
                         ],
                         ),
                       ),
                       alignment: Alignment.bottomRight,
                     ),
                     Container(
                       child: Image.asset('images/pizza.jpg'),
                       margin: EdgeInsets.only(top: 10.0),
                     ),
                     Container(
                       margin: EdgeInsets.only(bottom: 20),
                       decoration: BoxDecoration(color: Color(0xffE6915D),
                         borderRadius: BorderRadius.only(
                           bottomRight: Radius.circular(20),
                           bottomLeft: Radius.circular(20),
                         ),
                       ),
                       height: 80,
                       child: Padding(
                         padding: const EdgeInsets.all(5.0),
                         child: Column(
                           children: [
                             Text('بيتزا خضار',
                                 style: TextStyle(
                                 fontSize: 20.0,
                                 letterSpacing: 2.0,
                                 color: Colors.white,
                               ),
                             ),
                             Text('30 دقيقة',
                               style: TextStyle(
                                 fontSize: 15.0,
                                 letterSpacing: 2.0,
                                 color: Colors.white,
                               ),
                             ),
                           ],
                         ),
                       ),
                       alignment: Alignment.topRight,
                     ),
                 ],
                ),
          ),
          ),
      ),
    );
  }
}