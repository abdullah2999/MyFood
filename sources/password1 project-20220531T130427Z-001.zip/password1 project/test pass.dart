
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'inputDeco.dart';
class FormPage extends StatefulWidget {
  @override
  _FormPageState createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  late String email;

  //TextController to read text entered in text field
  TextEditingController password = TextEditingController();
  TextEditingController confirmpassword = TextEditingController();

  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      child: Scaffold(
        backgroundColor: Color(0xffE6915D),
        appBar: AppBar(backgroundColor: Color(0xffE6915D),
          title: Text('تغيير كلمة المرور'),
          leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.arrow_back),
            color: Colors.white,
          ),
        ),
        body: Center(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: SingleChildScrollView(
            key: _formkey,
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.all(20),
                  child: Image.asset("images/aklaty.png"),
                  height: 160,
                  width: 160,
                ),
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: TextFormField(
                    keyboardType: TextInputType.text,
                    decoration: buildInputDecoration(Icons.email, 'البريد الألكتروني',
                    ),
                    validator: (value){
                      if(value!.isEmpty) {
                        return 'ادخل البريد الألكتروني';
                      }
                      if(!RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]").hasMatch(value)){
                        return 'Please a valid Email';
                      }
                      return null;
                    },
                    onSaved: (value){
                      email = value!;
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: TextFormField(
                    controller: password,
                    keyboardType: TextInputType.text,
                    decoration: buildInputDecoration(Icons.lock,"كلمة المرور الجديدة"),
                      validator: (value){
                        if(value!.isEmpty)
                        {
                          return 'ادخل كلمة المرور الجديدة';
                        }
                        return null;
                      },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: TextFormField(
                    controller: confirmpassword,
                    obscureText: true,
                    keyboardType: TextInputType.text,
                    decoration:buildInputDecoration(Icons.lock,"تأكيد كلمة المرور"),
                    validator: (value){
                      if(value!.isEmpty)
                      {
                        return 'اعد كتابة  كلمة المرور';
                      }
                      print(password.text);

                      print(confirmpassword.text);

                      if(password.text!=confirmpassword.text){
                        return " كلمة المرور غير متشابهة";
                      }

                      return null;
                    },
                  ),
                ),
                SizedBox(
                  height: 30,
                ),

                SizedBox(
                  width: 200,
                  height: 50,
                  child: RaisedButton(
                    color: Color(0xffE6915D),
                    onPressed: (){

                      if(_formkey.currentState!.validate())
                      {
                        print("successful");

                        return;
                      }else{
                        print("UnSuccessfull");
                      }
                    },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50.0),
                        side: BorderSide(color: Colors.white,width: 1)
                    ),
                    textColor:Colors.white,child: Text("تأكيد"),

                  ),
                ),
                Divider(
                  thickness:1.5,
                  color: Colors.white,
                  indent: 110,
                  endIndent: 110,
                  height: 100,
                ),
              ],
            ),
          ),
        ),
        ),
      ),
    );
  }
}