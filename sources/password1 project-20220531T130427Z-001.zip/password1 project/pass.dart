

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class password extends StatefulWidget {
  @override
  State<password> createState() => _passwordState();
}

class _passwordState extends State<password> {
  @override
  Widget build(BuildContext context) {
    return Form(
      child: Scaffold(
        backgroundColor: Color(0xffE6915D),
        appBar: AppBar(backgroundColor: Color(0xffE6915D),
          title: Text('تغيير كلمة المرور'),
          leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.arrow_back),
            color: Colors.white,
          ),
        ),
        body:Center(
          child: Padding(
            padding: const EdgeInsets.all(2.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.all(20),
                    child: Image.asset('images/aklaty.png'),
                    height: 130,
                    width: 130,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10),
                      child: Column(
                        children: [
                          TextFormField(
                            decoration: InputDecoration(
                              border:OutlineInputBorder(),
                              focusColor: Colors.white,
                              filled: true,
                              hintText: 'البريد الألكتروني',
                              hintStyle:TextStyle(
                                color: Color(0xffffffff),
                              ),
                            ),
                            keyboardType: TextInputType.emailAddress,
                            style:TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                            ),
                          ),

                        ],
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(
                        validator: (value){
                         if(value!.isEmpty){
                          return 'null';
                         }else if(value.length>6){
                           return 'يجب ان يتضمن 6 احرف على الأقل';
                         }
                         },
                          onChanged: (value) => aaa = value,
                          obscureText: !_isVisible,
                          maxLength: 10,
                          decoration: InputDecoration(
                            suffixIcon: IconButton(
                              onPressed: () {
                                setState(() {
                                  _isVisible = !_isVisible;
                                });
                              },
                              icon: _isVisible ? Icon(Icons.visibility, color: Colors.white,): Icon(Icons.visibility_off, color: Colors.white,),
                            ),
                            hintText: "كلمة المرور الجديدة",
                            hintStyle:TextStyle(
                              color: Color(0xffffffff),
                            ),
                            border:OutlineInputBorder(),
                            focusColor: Colors.white,
                            filled: true,
                          ),
                          style:TextStyle(
                            fontSize: 20,
                            color: Colors.white,
                          ),
                        ),

                      ],
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      children: [
                        TextFormField(
                          validator: (value){
                            if( value != aaa){
                              return 'false';
                            }
                          },
                          onChanged: (value)=> bbb = value,
                          obscureText: !_isVisible,
                          maxLength: 10,
                          style:TextStyle(
                            fontSize: 20,
                            color: Colors.white,
                          ),
                          decoration: InputDecoration(
                            hintText: "تأكيد كلمة المرور",
                            hintStyle:TextStyle(
                              color: Color(0xffffffff),
                            ),
                            border: OutlineInputBorder(
                              borderSide: BorderSide(
                                color: Colors.white,
                              ),
                            ),
                            suffixIcon: IconButton(
                                onPressed: () {
                                  setState(() {
                                    _isVisible = !_isVisible;
                                  });
                                },
                              icon: _isVisible ? Icon(Icons.visibility, color: Colors.white,): Icon(Icons.visibility_off, color: Colors.white,),
                            ),
                          ),
                        ),

                      ],
                    ),
                  ),
                  SizedBox(height: 50,),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      primary: Colors.white,
                      side: BorderSide(color: Colors.white),
                      padding: EdgeInsets.symmetric(horizontal: 100, vertical: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                      onPressed: (){
                      if(_key.currentState!.validate());
                      },
                    child: Text("تأكيد", style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                    ),
                  ),
                  Divider(
                    thickness:1.5,
                    color: Colors.white,
                    indent: 110,
                    endIndent: 110,
                    height: 100,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
